# foro1
 # DSM941-G01
*App Movil Tienda o Carrito de compras*

## Integrantes - Grupo Teórico 01T
Caleb Verenice López Gutiérrez - LG211551

René Saúl Jovel Calderón - JC211517

Bryan Antonio Mena Cortez - MC211787

Andrea Gisselle Elías Henríquez - EH160454

Miriam Janeth Villeda Lopez - VL191443

## Enlaces
[Repositorio del código del servidor](https://github.com/BryanMena/foro1)

[Documento de Investigacion](https://udbedu-my.sharepoint.com/:b:/g/personal/lg211551_alumno_udb_edu_sv/EZak7X0_hvpCgb4izfFCel8BypZXFv2apIrwuvppHaw0oQ?e=19ZMf0)

[Video Expositivo del Proyecto](https://www.youtube.com/watch?v=PqnCuyMCwc0)


## Licencia
[![CC BY-SA 4.0][cc-by-sa-shield]][cc-by-sa]

Esta obra está sujeta a una licencia
[Creative Commons Attribution-ShareAlike 4.0 International License][cc-by-sa].

[![CC BY-SA 4.0][cc-by-sa-image]][cc-by-sa]

[cc-by-sa]: http://creativecommons.org/licenses/by-sa/4.0/
[cc-by-sa-image]: https://licensebuttons.net/l/by-sa/4.0/88x31.png
[cc-by-sa-shield]: https://img.shields.io/badge/License-CC%20BY--SA%204.0-lightgrey.svg

